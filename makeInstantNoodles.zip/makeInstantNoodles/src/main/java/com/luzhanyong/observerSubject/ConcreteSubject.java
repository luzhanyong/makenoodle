package com.luzhanyong.observerSubject;

import com.luzhanyong.product.Observer;

//具体的目标对象
public class ConcreteSubject extends Subject{
    //遍历观察者，触发观察者方法
    @Override
    public void notifyObserver(){
        for (Object obs : observers) {
            ((Observer) obs).response();
        }
    }
}

