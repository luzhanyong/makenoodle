package com.luzhanyong.factory;

import com.luzhanyong.product.Water;

//创建水的工厂接口
public interface WaterFactory {
    public Water newWater();
}
