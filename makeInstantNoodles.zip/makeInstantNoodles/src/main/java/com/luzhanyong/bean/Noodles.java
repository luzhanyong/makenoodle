package com.luzhanyong.bean;

public class Noodles {
    private String name = "面饼";
}
