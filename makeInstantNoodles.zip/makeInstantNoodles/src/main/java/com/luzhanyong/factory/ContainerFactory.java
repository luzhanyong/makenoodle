package com.luzhanyong.factory;

import com.luzhanyong.product.Container;

public interface ContainerFactory {
    public Container newContainer();
}
