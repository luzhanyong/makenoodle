package com.luzhanyong.product.impl;

import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;

public class Tomato implements SideDish, Observer {
    private boolean open = false;
    private String name = "番茄";


    //单例
    private static volatile Tomato instance = null;
    private Tomato() {//防止外部类实例化
    }
    public static synchronized Tomato getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new Tomato();
        }
        return instance;
    }

    @Override
    public boolean isOpen() {
        return open;
    }

    @Override
    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void response() {
        open = true;
    }

    @Override
    public void response2() {
        open=false;
    }
}
