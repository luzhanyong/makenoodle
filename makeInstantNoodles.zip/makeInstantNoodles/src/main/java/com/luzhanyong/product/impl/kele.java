package com.luzhanyong.product.impl;

import com.luzhanyong.product.Water;

public class kele implements Water {
    private String name="可乐";
    private boolean open = true;


    //单例
    private static volatile kele instance = null;
    private kele() {
    }
    public static synchronized kele getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new kele();
        }
        return instance;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }
}
