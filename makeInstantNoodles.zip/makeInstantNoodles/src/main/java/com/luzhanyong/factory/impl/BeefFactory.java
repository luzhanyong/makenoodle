package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.impl.Beef;

public class BeefFactory implements SideDishFactory {
    @Override
    public SideDish newSideDish() {
        return Beef.getInstance();
    }
}
