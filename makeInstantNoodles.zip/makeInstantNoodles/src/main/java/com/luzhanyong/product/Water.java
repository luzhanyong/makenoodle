package com.luzhanyong.product;

public interface Water {
    public String getName();
    public boolean isOpen();
    public void setOpen(boolean open);

}
