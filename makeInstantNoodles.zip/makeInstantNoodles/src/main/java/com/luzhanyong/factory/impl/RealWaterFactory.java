package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.WaterFactory;
import com.luzhanyong.product.Water;
import com.luzhanyong.product.impl.RealWater;

//创建纯净水工厂
public class RealWaterFactory implements WaterFactory{
    @Override
    public Water newWater() {
        return RealWater.getInstance();
    }
}
