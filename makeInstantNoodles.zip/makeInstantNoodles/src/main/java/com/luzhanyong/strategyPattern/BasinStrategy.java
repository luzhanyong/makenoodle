package com.luzhanyong.strategyPattern;

import com.luzhanyong.bean.Noodles;
import com.luzhanyong.factory.WaterFactory;
import com.luzhanyong.factory.impl.*;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;
import com.luzhanyong.service.ScoreService;
import com.luzhanyong.service.impl.ScoreServieImpl;

//策略2将用户选择的水和配料放入盆中
public class BasinStrategy implements Strategy{
    @Override
    public void strategyMethod(String[] waters, String[] sideDishes,Container basin) {

        //获得一个面饼
        Noodles noodles = new Noodles();
        basin.setNoodles(noodles);
        for (String water:waters) {
            if (water.equals("chu")){
                WaterFactory waterFactory = new RealWaterFactory();
                Water realWater = waterFactory.newWater();
                basin.addWater(realWater);
            }
            if (water.equals("milk")){
                MilkFactory milkFactory = new MilkFactory();
                Water milk = milkFactory.newWater();
                basin.addWater(milk);
            }
            if (water.equals("kele")){
                keleFactory keleFactory = new keleFactory();
                Water kele = keleFactory.newWater();
                basin.addWater(kele);
            }
        }
        //egg  tomato  sausage  beef
        for (String sideDish : sideDishes){
            if (sideDish.equals("egg")){
                EggFactory eggFactory = new EggFactory();
                SideDish egg = eggFactory.newSideDish();
                basin.addSideDish(egg);
            }
            if (sideDish.equals("tomato")){
                TomatoFactory tomatoFactory = new TomatoFactory();
                SideDish tomato = tomatoFactory.newSideDish();
                basin.addSideDish(tomato);
            }
            if (sideDish.equals("sausage")){
                SausageFactory sausageFactory = new SausageFactory();
                SideDish sausage = sausageFactory.newSideDish();
                basin.addSideDish(sausage);
            }
            if (sideDish.equals("beef")){
                BeefFactory beefFactory = new BeefFactory();
                SideDish beef = beefFactory.newSideDish();
                basin.addSideDish(beef);
            }
        }
    }

}
