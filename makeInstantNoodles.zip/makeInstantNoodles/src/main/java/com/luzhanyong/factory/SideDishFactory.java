package com.luzhanyong.factory;

import com.luzhanyong.product.SideDish;

public interface SideDishFactory {
    public SideDish newSideDish();
}
