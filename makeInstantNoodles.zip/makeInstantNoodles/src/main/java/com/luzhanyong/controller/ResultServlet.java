package com.luzhanyong.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class ResultServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");    //设置 HttpServletResponse使用utf-8编码
        resp.setHeader("Content-Type", "text/html;charset=utf-8");    //通知浏览器使用utf-8解码
        HttpSession session = req.getSession();
        int score = (int) session.getAttribute("score");
        StringBuffer review = (StringBuffer) session.getAttribute("review");
        PrintWriter writer = resp.getWriter();
        Map map = new HashMap();
        map.put("mess","ok");
        map.put("score",score);
        map.put("review",review);
        Gson gson = new Gson();
        String json = gson.toJson(map);
        writer.print(json);
    }
}
