package com.luzhanyong.product.impl;

import com.luzhanyong.product.Water;

//具体的纯净水产品
public class RealWater implements Water {
    private String name="纯净水";
    private boolean open = true;

    //单例
    private static volatile RealWater instance = null;
    private RealWater() {//防止外部类实例化
    }
    public static synchronized RealWater getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new RealWater();
        }
        return instance;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }
}
