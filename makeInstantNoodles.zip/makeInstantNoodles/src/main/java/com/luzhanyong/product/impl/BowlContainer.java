package com.luzhanyong.product.impl;

import com.luzhanyong.bean.Noodles;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;

import java.util.ArrayList;
import java.util.List;

public class BowlContainer implements Container {
    private Noodles noodles;
    private List<Water> waterList = new ArrayList<Water>();
    private List<SideDish> sideDishList = new ArrayList<SideDish>();


    public Noodles getNoodles() {
        return noodles;
    }

    public void setNoodles(Noodles noodles) {
        this.noodles = noodles;
    }

    public List<Water> getWater() {
        return waterList;
    }

    public void addWater(Water water) {
        waterList.add(water);
    }

    public List<SideDish> getSideDish() {
        return sideDishList;
    }

    public void addSideDish(SideDish sideDish) {
        sideDishList.add(sideDish);
    }
}
