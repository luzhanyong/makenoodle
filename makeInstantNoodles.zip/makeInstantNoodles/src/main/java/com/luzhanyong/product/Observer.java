package com.luzhanyong.product;

//观察者接口，因为两个观察者模式的观察者对象是一样了，就将两个观察者模式中的接口写在一起了
public interface Observer {
    public void response();
    public void response2();

}
