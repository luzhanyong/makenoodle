package com.luzhanyong.product.impl;

import com.luzhanyong.product.Observer;
import com.luzhanyong.product.Water;

//具体的观察者牛奶，
public class Milk implements Water,Observer {
    private String name = "牛奶";
    private boolean open =false;
    private boolean select;



    //单例
    private static volatile Milk instance = null;
    private Milk() {
    }
    public static synchronized Milk getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new Milk();
        }
        return instance;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }
    //观察目标变化，观察者触发的方法
    @Override
    public void response() {
        open = true;
    }
    //观察目标变化，观察者触发的方法
    @Override
    public void response2() {
        open=false;
    }
}
