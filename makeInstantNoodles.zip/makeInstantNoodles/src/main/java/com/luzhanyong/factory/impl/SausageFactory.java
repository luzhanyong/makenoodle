package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.impl.Sausage;

public class SausageFactory implements SideDishFactory {
    @Override
    public SideDish newSideDish() {
        return Sausage.getInstance();
    }
}
