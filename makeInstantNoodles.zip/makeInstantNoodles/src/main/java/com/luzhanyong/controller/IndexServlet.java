package com.luzhanyong.controller;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.factory.impl.*;
import com.luzhanyong.observerSubject.ConcreteSubject;
import com.luzhanyong.observerSubject.ConcreteSubject2;
import com.luzhanyong.observerSubject.Subject;
import com.luzhanyong.observerSubject.Subject2;
import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;
import com.luzhanyong.product.impl.Egg;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//系统首页处理的servlet，初始化对象，并且进入不同的系统模块
public class IndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        req.setCharacterEncoding("utf-8");
        //初始化对象

        //创建具体的观察者2 关闭vip功能
        Subject2 concreteSubject = new ConcreteSubject2();
        //创建牛奶 并添加观察者
        MilkFactory milkFactory = new MilkFactory();
        //用Observer接收工厂创建出来的产品，只能使用Oberver接口的方法
        //当一个类被实现两个接口时，在实例化的过程中，需要注意用特定的接口指代它，可能需要强转
        Observer milk = (Observer) milkFactory.newWater();
        Water water = milkFactory.newWater();
        concreteSubject.add(milk);
        //创建鸡蛋 并添加观察者
        SideDishFactory eggFactory = new EggFactory();
        Observer egg = (Observer) eggFactory.newSideDish();
        SideDish sideDish = eggFactory.newSideDish();
        concreteSubject.add(egg);
        //创建香肠，并添加观察者
        SideDishFactory sausageFactory = new SausageFactory();
        Observer sausage = (Observer) sausageFactory.newSideDish();
        SideDish sideDish1 = sausageFactory.newSideDish();
        concreteSubject.add(sausage);
        //创建番茄，并添加观察者
        SideDishFactory tomatoFactory = new TomatoFactory();
        Observer tomato = (Observer) tomatoFactory.newSideDish();
        SideDish sideDish2 = tomatoFactory.newSideDish();
        concreteSubject.add(tomato);
        //创建牛肉，并添加观察者
        SideDishFactory beefFactory = new BeefFactory();
        Observer beef = (Observer) beefFactory.newSideDish();
        SideDish sideDish3 = beefFactory.newSideDish();
        concreteSubject.add(beef);
        //开通vip成功，遍历循环观察者
        concreteSubject.notifyObserver();
        String target = req.getParameter("target");
        if (target.equals("1")){
            resp.sendRedirect(req.getContextPath()+"/make");
        }else if (target.equals("2")){
            resp.sendRedirect(req.getContextPath()+"/food");
        }
    }
}
