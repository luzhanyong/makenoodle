package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.ContainerFactory;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.impl.BowlContainer;

public class BowlContainerFactory implements ContainerFactory {
    @Override
    public Container newContainer() {
        return new BowlContainer();
    }
}
