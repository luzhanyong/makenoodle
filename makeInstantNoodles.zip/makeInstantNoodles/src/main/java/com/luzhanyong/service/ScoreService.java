package com.luzhanyong.service;

import com.luzhanyong.product.Container;

public interface ScoreService {
    public int score(Container container);
    public StringBuffer review(Container container);
}
