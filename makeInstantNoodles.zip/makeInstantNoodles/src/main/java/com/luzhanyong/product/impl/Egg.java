package com.luzhanyong.product.impl;

import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;

public class Egg implements SideDish , Observer {
    private boolean open = false;
    private String name = "鸡蛋";
    private boolean select;



    //单例
    private static volatile Egg instance = null;
    private Egg() {
    }
    public static synchronized Egg getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new Egg();
        }
        return instance;
    }


    @Override
    public boolean isOpen() {
        return open;
    }

    @Override
    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void response() {
        open = true;
    }

    @Override
    public void response2() {
        open=false;
    }
}
