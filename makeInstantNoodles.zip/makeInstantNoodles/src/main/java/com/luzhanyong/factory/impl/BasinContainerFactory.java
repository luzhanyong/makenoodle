package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.ContainerFactory;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.impl.BasinContainer;

public class BasinContainerFactory implements ContainerFactory {
    @Override
    public Container newContainer() {
        return new BasinContainer();
    }
}
