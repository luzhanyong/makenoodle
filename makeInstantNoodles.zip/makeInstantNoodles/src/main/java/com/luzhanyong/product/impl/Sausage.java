package com.luzhanyong.product.impl;

import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;

public class Sausage implements SideDish, Observer {
    private boolean open = false;
    private String name = "香肠";


    //单例
    private static volatile Sausage instance = null;
    private Sausage() {//防止外部类实例化
    }
    public static synchronized Sausage getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new Sausage();
        }
        return instance;
    }

    @Override
    public boolean isOpen() {
        return open;
    }

    @Override
    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void response() {
        open = true;
    }

    @Override
    public void response2() {
        open=false;
    }
}
