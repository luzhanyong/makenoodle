package com.luzhanyong.controller;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.factory.impl.*;
import com.luzhanyong.observerSubject.ConcreteSubject;
import com.luzhanyong.observerSubject.Subject;
import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;
import com.luzhanyong.product.impl.Egg;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

//使用观察者模式，升级vip，添加观察者并且通知观察者
public class IsOpenServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        //创建具体的观察者1 打开vip功能
        Subject concreteSubject = new ConcreteSubject();
        //创建牛奶 并添加观察者
        MilkFactory milkFactory = new MilkFactory();
        //用Observer接收工厂创建出来的产品，只能使用Oberver接口的方法
        //当一个类被实现两个接口时，在实例化的过程中，需要注意用特定的接口指代它，可能需要强转
        Observer milk = (Observer) milkFactory.newWater();
        concreteSubject.add(milk);
        //创建鸡蛋 并添加观察者
        SideDishFactory eggFactory = new EggFactory();
        Observer egg = (Observer) eggFactory.newSideDish();
        concreteSubject.add(egg);
        //创建香肠，并添加观察者
        SideDishFactory sausageFactory = new SausageFactory();
        Observer sausage = (Observer) sausageFactory.newSideDish();
        concreteSubject.add(sausage);
        //创建番茄，并添加观察者
        SideDishFactory tomatoFactory = new TomatoFactory();
        Observer tomato = (Observer) tomatoFactory.newSideDish();
        concreteSubject.add(tomato);
        //创建牛肉，并添加观察者
        SideDishFactory beefFactory = new BeefFactory();
        Observer beef = (Observer) beefFactory.newSideDish();
        concreteSubject.add(beef);
        //开通vip成功，遍历循环观察者
        concreteSubject.notifyObserver();
        req.getRequestDispatcher("/isOrNoOpen").forward(req,resp);
    }
}
