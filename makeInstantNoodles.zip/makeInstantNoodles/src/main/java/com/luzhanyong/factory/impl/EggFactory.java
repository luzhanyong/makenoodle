package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.impl.Egg;

public class EggFactory implements SideDishFactory {
    @Override
    public SideDish newSideDish() {
        return Egg.getInstance();
    }
}
