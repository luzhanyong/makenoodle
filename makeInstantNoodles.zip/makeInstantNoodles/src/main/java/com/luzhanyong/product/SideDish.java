package com.luzhanyong.product;

public interface SideDish {
    public String getName();
    public boolean isOpen();

    public void setOpen(boolean open);
}
