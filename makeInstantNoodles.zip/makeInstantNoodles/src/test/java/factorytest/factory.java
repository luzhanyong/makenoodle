package factorytest;

import com.luzhanyong.factory.impl.RealWaterFactory;
import com.luzhanyong.product.Water;
import org.junit.Test;

public class factory {

    //编写测试用例，测试工厂和单例
    @Test
    public void test1(){
        //创建一个第一个纯净水
        RealWaterFactory realWaterFactory = new RealWaterFactory();
        Water water = realWaterFactory.newWater();
        //设置open为true 默认是false
        water.setOpen(true);
        //创建第二个纯净水
        RealWaterFactory realWaterFactory2 = new RealWaterFactory();
        Water water2 = realWaterFactory.newWater();
        boolean open = water2.isOpen();
        //如果open==true则是同一个纯净水
        System.out.println(open);
    }
}
