package com.luzhanyong.controller;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.factory.impl.*;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class IsOrNoOpenServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        MilkFactory milkFactory = new MilkFactory();
        Water water = milkFactory.newWater();
        SideDishFactory eggFactory = new EggFactory();
        SideDish egg = eggFactory.newSideDish();
        SideDishFactory sausageFactory = new SausageFactory();
        SideDish sausage = sausageFactory.newSideDish();
        SideDishFactory tomatoFactory = new TomatoFactory();
        SideDish tomato = tomatoFactory.newSideDish();
        SideDishFactory beefFactory = new BeefFactory();
        SideDish beef = beefFactory.newSideDish();
        if (water.isOpen() && egg.isOpen() && sausage.isOpen() && tomato.isOpen() && beef.isOpen()){
            PrintWriter writer = resp.getWriter();
            writer.print("ok");
        }else {
            PrintWriter writer = resp.getWriter();
            writer.print("no");
        }
    }
}
