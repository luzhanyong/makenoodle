package com.luzhanyong.product.impl;

import com.luzhanyong.product.Observer;
import com.luzhanyong.product.SideDish;

public class Beef implements SideDish , Observer {
    private boolean open = false;
    private String name = "牛肉";

    //单例
    private static volatile Beef instance = null;
    private Beef() {
    }
    public static synchronized Beef getInstance() {
        //getInstance 方法前加同步
        if (instance == null) {
            instance = new Beef();
        }
        return instance;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void response() {
        open = true;
    }

    @Override
    public void response2() {
        open=false;
    }
}
