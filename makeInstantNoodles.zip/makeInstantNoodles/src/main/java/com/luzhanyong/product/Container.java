package com.luzhanyong.product;

import com.luzhanyong.bean.Noodles;

import java.util.List;

public interface Container {
    public Noodles getNoodles();

    public void setNoodles(Noodles noodles);

    public List<Water> getWater();

    public void addWater(Water water);

    public List<SideDish> getSideDish();

    public void addSideDish(SideDish sideDish);
}
