package com.luzhanyong.observerSubject;

import com.luzhanyong.product.Observer;

public class ConcreteSubject2 extends Subject2{
    @Override
        public void notifyObserver(){
            for (Object obs : observers) {
                ((Observer) obs).response2();
            }
        }
    }

