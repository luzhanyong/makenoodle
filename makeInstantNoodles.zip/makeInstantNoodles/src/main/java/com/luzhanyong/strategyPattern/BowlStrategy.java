package com.luzhanyong.strategyPattern;

import com.luzhanyong.bean.Noodles;
import com.luzhanyong.factory.WaterFactory;
import com.luzhanyong.factory.impl.*;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;


//策略1将用户选择的水和配料放入碗中
public class BowlStrategy implements Strategy{
    @Override
    public void strategyMethod(String[] waters, String[] sideDishes,Container bowl) {
        //获得面饼
        Noodles noodles = new Noodles();
        bowl.setNoodles(noodles);
        for (String water:waters) {
            if (water.equals("realWater")){
                WaterFactory waterFactory = new RealWaterFactory();
                Water realWater = waterFactory.newWater();
                bowl.addWater(realWater);
            }
            if (water.equals("milk")){
                MilkFactory milkFactory = new MilkFactory();
                Water milk = milkFactory.newWater();
                bowl.addWater(milk);
            }
            if (water.equals("kele")){
                keleFactory keleFactory = new keleFactory();
                Water kele = keleFactory.newWater();
                bowl.addWater(kele);
            }
        }
        //egg  tomato  sausage  beef
        for (String sideDish: sideDishes){
            if (sideDish.equals("egg")){
                EggFactory eggFactory = new EggFactory();
                SideDish egg = eggFactory.newSideDish();
                bowl.addSideDish(egg);
            }
            if (sideDish.equals("tomato")){
                TomatoFactory tomatoFactory = new TomatoFactory();
                SideDish tomato = tomatoFactory.newSideDish();
                bowl.addSideDish(tomato);
            }
            if (sideDish.equals("sausage")){
                SausageFactory sausageFactory = new SausageFactory();
                SideDish sausage = sausageFactory.newSideDish();
                bowl.addSideDish(sausage);
            }
            if (sideDish.equals("beef")){
                BeefFactory beefFactory = new BeefFactory();
                SideDish beef = beefFactory.newSideDish();
                bowl.addSideDish(beef);
            }
        }
    }
}
