package com.luzhanyong.strategyPattern;

import com.luzhanyong.product.Container;
import com.luzhanyong.product.Water;

//策略接口
public interface Strategy {
    public void strategyMethod(String[] waters, String[] sideDishes, Container container);
}
