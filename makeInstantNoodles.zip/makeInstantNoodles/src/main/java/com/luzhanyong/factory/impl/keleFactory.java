package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.WaterFactory;
import com.luzhanyong.product.Water;
import com.luzhanyong.product.impl.kele;

public class keleFactory implements WaterFactory {
    @Override
    public Water newWater() {
        return kele.getInstance();
    }
}
