package com.luzhanyong.controller;

import com.luzhanyong.bean.Noodles;
import com.luzhanyong.factory.ContainerFactory;
import com.luzhanyong.factory.impl.BasinContainerFactory;
import com.luzhanyong.factory.impl.BowlContainerFactory;
import com.luzhanyong.factory.impl.RealWaterFactory;
import com.luzhanyong.product.Container;
import com.luzhanyong.product.Water;
import com.luzhanyong.service.ScoreService;
import com.luzhanyong.service.impl.ScoreServieImpl;
import com.luzhanyong.strategyPattern.BasinStrategy;
import com.luzhanyong.strategyPattern.BowlStrategy;
import com.luzhanyong.strategyPattern.Strategy;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

//环境类选择不同的策略
public class MakeContainerServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        //取出选择的容器
        String container = req.getParameter("container");
        //获得选择的水
        String[] waters = req.getParameterValues("water");
        //获得选择的配料
        String[] sidedishes = req.getParameterValues("sidedish");
        //创建评分评论
        ScoreService scoreService = new ScoreServieImpl();
        //使用策略2
        if (container.equals("bowl")) {
            //创建碗容器
            BasinContainerFactory basinContainerFactory = new BasinContainerFactory();
            Container basin = basinContainerFactory.newContainer();
            //使用碗策略
            Strategy bowlStrategy = new BowlStrategy();
            bowlStrategy.strategyMethod(waters,sidedishes,basin);
            //评分和评论

            int score = scoreService.score(basin);
            StringBuffer review = scoreService.review(basin);
            HttpSession session = req.getSession();
            session.setAttribute("score",score);
            session.setAttribute("review",review);
        }else if (container.equals("basin")){//使用策略1
            //创建脚盆容器
            BasinContainerFactory basinContainerFactory = new BasinContainerFactory();
            Container bowl = basinContainerFactory.newContainer();
            //创建脚盆策略
            Strategy basinStrategy = new BasinStrategy();
            basinStrategy.strategyMethod(waters,sidedishes,bowl);
            //评分和评论
            int score = scoreService.score(bowl);
            StringBuffer review = scoreService.review(bowl);
            HttpSession session = req.getSession();
            session.setAttribute("score",score);
            session.setAttribute("review",review);
        }
        //转发
        req.getRequestDispatcher("/result.html").forward(req,resp);
    }

}
