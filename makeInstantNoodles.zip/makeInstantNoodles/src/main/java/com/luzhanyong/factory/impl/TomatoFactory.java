package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.SideDishFactory;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.impl.Tomato;

public class TomatoFactory implements SideDishFactory {
    @Override
    public SideDish newSideDish() {
        return Tomato.getInstance();
    }
}
