package com.luzhanyong.service.impl;

import com.luzhanyong.product.Container;
import com.luzhanyong.product.SideDish;
import com.luzhanyong.product.Water;
import com.luzhanyong.service.ScoreService;

import java.util.List;

public class ScoreServieImpl implements ScoreService {

    @Override
    public int score(Container container) {
        int score=1;
        List<Water> waters = container.getWater();
        List<SideDish> sideDishes = container.getSideDish();
        for (Water water:waters) {
            String name = water.getName();
            if (name.equals("纯净水") ){
                score+= 1;
            }
            if (name.equals("牛奶") ){
                score+= 2;
            }
            if (name.equals("可乐")){
                score-= 1;
            }
        }
        for (SideDish sideDish:sideDishes) {
            String name = sideDish.getName();
            if (name.equals("鸡蛋")){
                score+=2;
            }
            if (name.equals("香肠")){
                score+=1;
            }
            if (name.equals("番茄")){
                score+=2;
            }
            if (name.equals("牛肉")){
                score+=2;
            }
        }

        return score;
    }

    @Override
    public StringBuffer review(Container container) {
        StringBuffer reviews = new StringBuffer("你是一个灵魂的泡面高手，你使用的水有:");
        List<Water> waters = container.getWater();
        List<SideDish> sideDishes = container.getSideDish();
        for (Water water:waters) {
            String name = water.getName();
            reviews.append(name);
            if (name.equals("纯净水")){
                reviews.append(",纯净水是生命的源泉,加入纯净水是正确的选择！");
            }
            if (name.equals("牛奶")){
                reviews.append(",牛奶有很多营养，但不要加太多容易甜！");

            }
            if (name.equals("可乐")){
                reviews.append(",你真是个天才，可乐你也敢加！");
            }
        }
        for (SideDish sideDish:sideDishes) {
            String name = sideDish.getName();
            reviews.append(name);
            if (name.equals("鸡蛋")){
                reviews.append(",鸡蛋有很多蛋白质，能让你充满能量!也让你的泡面增加更多美味！");
            }
            if (name.equals("香肠")){
                reviews.append(",香肠和泡面是灵魂的搭配！");
            }
            if (name.equals("番茄")){
                reviews.append(",番茄让你的泡面更加的鲜美,我也喜欢番茄");
            }
            if (name.equals("牛肉")){
                reviews.append(",是英雄都爱吃牛肉,牛肉面很美味,关键的是肉谁不喜欢吃啊");
            }
        }
        return reviews;
    }
}
