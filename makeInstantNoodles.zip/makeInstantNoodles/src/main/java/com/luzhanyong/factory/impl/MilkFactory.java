package com.luzhanyong.factory.impl;

import com.luzhanyong.factory.WaterFactory;
import com.luzhanyong.product.Water;
import com.luzhanyong.product.impl.Milk;

public class MilkFactory implements WaterFactory {
    @Override
    public Water newWater() {
        return Milk.getInstance();
    }
}
